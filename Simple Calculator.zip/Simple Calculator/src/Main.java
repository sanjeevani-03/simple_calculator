import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    static int add(int a, int b){ //function to add two numbers
        return a+b;
    }

    static int subtract(int a, int b){ //function to subtract two numbers
        return a-b;
    }

    static int multiply(int a, int b){ //function to multiply two numbers
        return a*b;
    }

    static float divide(int a, int b){ //function to divide two numbers
        return (float) a/b;
    }

    static int[] getInputs(Scanner sc){ //used to get inputs
        int[] inputs = new int [2];

        try{
            System.out.println("Enter first number: ");
            inputs[0] = sc.nextInt();
            System.out.println("Enter second number: ");
            inputs[1] = sc.nextInt();
        }
        catch (InputMismatchException e){
            System.out.println("Invalid Input !!!, Please enter valid integers."); //case handled if values are not entered
            sc.nextLine();
            return null; //returning null so as output is not generated in that case
        }

        return inputs;
    }

    public static void main(String[] args) {
        //creating an object of scanner class
        Scanner sc = new Scanner(System.in);

        //perform calculation operation till user wants
        int loop = 1;

        while(loop == 1){
            //asking user for operation to be performed:
            System.out.println("Choose the operation you want to perform: ");
            System.out.println("1: Addition.");
            System.out.println("2. Subtraction.");
            System.out.println("3. Multiplication.");
            System.out.println("4. Division.");
            System.out.println("5. Exit.");
            int user_choice;

            try{
                System.out.println("Enter your choice: ");
                user_choice = sc.nextInt();
            } catch(InputMismatchException e){
                System.out.println("Invalid choice !!!, Enter valid choice");
                sc.nextLine();
                continue;
            }

            //now, asking for user inputs
            switch (user_choice){

                case 1: //if user wants to add
                    int[] inputA = getInputs(sc);
                    if(inputA == null){
                        System.out.println("Operation cannot be completed due to incorrect outputs.");
                        break;
                    }
                    int ans = add(inputA[0], inputA[1]);
                    System.out.printf("%d + %d = %d", inputA[0], inputA[1], ans);
                    System.out.println();
                    break;

                case 2: //if user wants to subtract
                    int[] inputS = getInputs(sc);
                    if(inputS == null){
                        System.out.println("Operation cannot be completed due to incorrect outputs.");
                        break;
                    }
                    int s3 = subtract(inputS[0], inputS[1]);
                    System.out.printf("%d - %d = %d", inputS[0], inputS[1], s3);
                    System.out.println();
                    break;

                case 3: //if user wants to multiply two numbers
                    int[] inputM = getInputs(sc);
                    if(inputM == null){
                        System.out.println("Operation cannot be completed due to incorrect outputs.");
                        break;
                    }
                    int p3 = multiply(inputM[0], inputM[1]);
                    System.out.printf("%d * %d = %d", inputM[0], inputM[1], p3);
                    System.out.println();
                    break;

                case 4: //if user wants to divide two numbers
                    int[] inputD = getInputs(sc);
                    if(inputD == null){
                        System.out.println("Operation cannot be completed due to incorrect outputs.");
                        break;
                    }
                    if(inputD[1] == 0){
                        System.out.println("Divide by zero is not allowed !!!");
                    }
                    else {
                        float d3 = divide(inputD[0], inputD[1]);
                        System.out.printf("%d / %d = %.2f", inputD[0], inputD[1], d3);
                        System.out.println();
                    }
                    break;

                case 5: //if user do not want to continue the calculation operation
                    System.out.println("Are you sure to exit ? (yes-1/no-0)");
                    int confirm = sc.nextInt();
                    if(confirm == 1) loop = 0;
                    else if (confirm == 0) break;
                    else System.out.println("Invalid Choice !!!");
                    break;

                default: //if user selects other choice
                    System.out.println("Incorrect choice !!!");
                    System.out.println();
                    break;
            }
        }
    }
}